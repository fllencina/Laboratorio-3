
//  window.addEventListener("load",function(){
//     var boton=document.getElementById('btnGuardar');//boton=$('btnGuardar);
//     boton.addEventListener("click",agregar);
        //     localStorage.setItem("clave","valor");

        //    if(localStorage.getItem("clave")!=null) {

        //    }
        //    else{
        //     LeerGet();
        //    }
// });
function $(id){
    return document.getElementById('id');
}
var arrayPersonas=[];
var FilaEliminarSeleccionada;
function Agregar(){
     var nombre=document.getElementById('inputNombre').value;
     var apellido=document.getElementById('inputApellido').value;
    
     if(nombre=='')
     {
         nombre.className="Error";
     }
     if(apellido=='')
     {
         apellido.className="Error";
     }
     else{
        if(confirm("Esta seguro que desea agregar?")==true)
        {
            var tBody=document.getElementById('tCuerpo');
            var Fila=tBody.insertRow(0);
            var celdaNombre=Fila.insertCell(0);
            var celdaApellido=Fila.insertCell(1);
            var celdaAccion=Fila.insertCell(2);
            celdaNombre.innerHTML='Nombre';
            celdaApellido.innerHTML='Apellido';
            celdaAccion.innerHTML="<a href=''> Borrar";
            
            
            // tBody.innerHTML=tBody.innerHTML + "<tr><td>"+nombre+"</td><td>"+apellido+"</td><td><a href=''>borrar</td></tr>"
        }
     }
     
}
function cerrar()
{
    document.getElementById('divIngreso').style.display='none';
}
function AbrirAgregar(){
    document.getElementById('divIngreso').style.display='inline-block';
}


var xml=new XMLHttpRequest();
window.addEventListener("load",LeerGet);
    //var btn= $('btn');
    //btn.addEventListener("click",LeerGet);
    // btn.addEventListener("click",enviarGet);
    
var indexSeleccionado;
function callback()
{
    if(xml.readyState===4){
        if(xml.status===200)
        {
            var respuesta=xml.responseText;      
                // alert("levanto ok");  
                localStorage.setItem("storage",respuesta);
                alert(localStorage.getItem("storage"));

                var listaPersonas=JSON.parse(respuesta);
                CompletaTabla(listaPersonas);            
        }
        
        else{
            alert("error en el servidor");
        }
    }
}
function LeerGet(){

        xml.open("GET","http://localhost:3000/personas",true);

        xml.onreadystatechange=callback;

        xml.send();

    }

function CompletaTabla(Personas)
{ 
    
    var Tabla=document.getElementById('tablaPersonas');

    for(var i=0;i<Personas.length;i++){
        
        // var Fila=Tabla.insertRow(i+1);      
        // var CeldaNombre=Fila.insertCell(0);
        // var CeldaApellido=Fila.insertCell(1);
        // var CeldaFecha=Fila.insertCell(2);
        // var CeldaTelefono=Fila.insertCell(3);
        // var CeldaAccion=Fila.insertCell(4);

        var FilaRow=document.createElement('tr');
        var obj=Personas[i];
      
        var columns=Object.keys(obj); //retorna array string de claves
        for(var j=0;j<columns.length;j++)
        {
            
            
            var cel=document.createElement('td');
            var text=document.createTextNode(obj[columns[j]]);
            cel.appendChild(text);
            FilaRow.appendChild(cel);
        }
        var cel=document.createElement('td');
        var link=document.createElement('a');
        link.setAttribute("href",'#');
        link.addEventListener("click",Eliminar);
        var text=document.createTextNode("borrar");
        link.appendChild(text);
        cel.appendChild(link);
        FilaRow.appendChild(cel);

        // var celda=document.createElement('td');
        // var link2=document.createElement('a');
        // link2.setAttribute("href",'#');
        // link2.addEventListener("click",Modificar);
        // var text2=document.createTextNode("Modificar");
        // link2.appendChild(text2);
        // celda.appendChild(link2);
        // FilaRow.appendChild(celda);
        // var CeldaNombreRow=document.createElement('td');
        // var CeldaApellidoRow=document.createElement('td');
        // var CeldaFechaRow=document.createElement('td');
        // var CeldaTelefonoRow=document.createElement('td');
        // var CeldaAccionRow=document.createElement('td');

        // CeldaNombreRow.innerHTML=Personas[i].nombre;
        // CeldaApellidoRow.innerHTML=Personas[i].apellido;
        // CeldaFechaRow.innerHTML=Personas[i].fecha;
        // CeldaTelefonoRow.innerHTML=Personas[i].telefono;
        // CeldaNombre.innerHTML=Personas[i].nombre;
        // CeldaApellido.innerHTML=Personas[i].apellido;
        // CeldaFecha.innerHTML=Personas[i].fecha;
        // CeldaTelefono.innerHTML=Personas[i].telefono;  
        // CeldaAccionRow.innerHTML='Borrar';
        // CeldaAccionRow.className='AccionBorrar';
        // CeldaAccionRow.onclick=function(){
            
        //     Eliminar(FilaRow);
        // }
        // CeldaAccion.innerHTML='Borrar';
        // CeldaAccion.className='AccionBorrar';
        // CeldaAccion.onclick=function(){
            
        //     Eliminar(FilaEliminarSeleccionada);
        // }
        
    //    FilaRow.appendChild(CeldaNombreRow);
    //    FilaRow.appendChild(CeldaApellidoRow);
    //    FilaRow.appendChild(CeldaFechaRow);
    //    FilaRow.appendChild(CeldaTelefonoRow);
    //    FilaRow.appendChild(CeldaAccionRow);
       Tabla.appendChild(FilaRow);
    }
    
}
    function Eliminar (event) {
        event.preventDefault();//saca valores por defecto del evento 
        event.target;//me devuelve el componente que lanza el evento
       var padre= (event.target.parentNode).parentNode;
       padre.parentNode.removeChild(padre);
       
    }

    // function Modificar(event) //local storage
    // {
    //     event.preventDefault();
    //     event.target;
        
    //     console.log(event.target);
        

    // }